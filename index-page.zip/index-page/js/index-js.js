

function myFunction(x) {

	if(x=='open'){

     document.getElementById('t-index-close-menu ').classList.toggle("change"); 
     document.getElementById('t-index-open-menu').style.display="none"; 
     $(".run").on("click", function() {
    $(".t-index-overlay-menu").addClass("show");
});

}
    else{

    	document.getElementById('t-index-close-menu ').classList.toggle("change");
        document.getElementById('t-index-open-menu').style.display="block"; 

$(".t-index-overlay-menu").on("click", function() {
  $(".t-index-overlay-menu").removeClass("show");

});
    }
    
}



$(document).ready(function() {

    $("#university-slider").owlCarousel({

        navigation : true, // Show next and prev buttons
        slideSpeed : 300,
        paginationSpeed : 400,
        items :6,
        autoPlay: true,
        autoPlay: 3000,


//       "singleItem:true" is a shortcut for:
//       items : 1,
//       itemsDesktop : false,
//       itemsDesktopSmall : false,
//      itemsTablet: false,
//       itemsMobile : false

    });

});



